

import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
curs=con.cursor()

curs.execute("select * from MOBILES")
data=curs.fetchall()
print(data)
con.close()
