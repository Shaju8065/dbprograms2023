import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
curs=con.cursor()

try:
    prodid=int(input('Enter Product ID: '))

    curs.execute("select * from MOBILES where prodid=%d" %prodid)
    data=curs.fetchone()

    if data:
        print(data)
        price=input('Enter new Price of Mobile : ')
        curs.execute("update MOBILES set price='%d' where Prodid=%d" %(price,prodid))
        con.commit()
        print('Price changed successfully')
    else:
        print('Product does not exist')
except:
    print('Error')

con.close()