import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
curs=con.cursor()

modelname=input('Enter the modelname : ')

curs.execute("Select * from MOBILES ")
data=curs.fetchone()
if data:
    print(data)
else:
    print('Data not Found')

con.close()
