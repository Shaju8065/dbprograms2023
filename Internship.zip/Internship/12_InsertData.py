import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')

curs=con.cursor()
#cursor=con.cursor()
#insert_stmt = 
query_2="UPDATE MOBILES SET purpose = 'Gaming' where prodid=101;"
curs.execute(query_2)
query_3="UPDATE MOBILES SET purpose = 'Social' where prodid=102;"
curs.execute(query_3)
query_4="UPDATE MOBILES SET purpose = 'Social' where prodid=103;"
curs.execute(query_4)
query_5="UPDATE MOBILES SET purpose = 'Office' where prodid=104;"
curs.execute(query_5)
  
curs.execute("select * from MOBILES;")
myresult = curs.fetchall()
for row in myresult:
    print(row)
  
con.commit()
  
# close the Connection
con.close()
     
        