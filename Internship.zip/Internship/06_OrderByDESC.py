import pymysql
 

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
curs=con.cursor()

mycursor = con.cursor()

sql = "SELECT * FROM MOBILES ORDER BY price DESC "

mycursor.execute(sql)

myresult = mycursor.fetchall()

thistuple=("price,")
print(type(thistuple))

for price in myresult:
  print(price)