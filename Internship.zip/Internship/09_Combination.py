import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
curs=con.cursor()

try:
    ram=(input('Enter RAM: '))

    curs.execute("select * from MOBILES where ram=%d" %ram)
    data=curs.fetchone()

    if data:
        print(data)
        rom=input('Enter ROM: ')
        curs.execute("update MOBILES set ram='%d' where rom=%d" %(ram,rom))
        con.commit()
        print('Ram and Rom Display successfully')
    else:
        print('Wrong Mobile Input')
except:
    print('Error')

con.close()