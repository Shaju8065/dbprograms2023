

import pymysql
try:

    con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
    curs=con.cursor()

    Prodid=int(input('Enter product ID : '))
    modelname=input('Enter Model name : ')
    company=input('Enter company of mobile: ')
    connectivity=(input('Enter connectivity in (4G or 5G) : '))
    ram=input('Ram: ')
    rom=input('Rom: ')
    color=input('Enter a Mobile Color: ')
    screen=input('Enter type of Display you want: ')
    battery=input('Enter Battery Capacity: ')
    processor=input('Enter type of Processor ')
    price=int(input('Price: '))
    rating=float(input('Rating: '))
    curs.execute("insert into MOBILES values('%d','%s','%s','%s','%s','%s','%s','%s''%d''%f')" %(Prodid,modelname,company,connectivity,ram,rom,color,screen,battery,processor,price))
    con.commit()
    print('New Mobile added to the table')
    con.close()
    curs.curs_set.execute("select * from MOBILES")
    data=curs.curs_set.fetchall()
    print(data)  
    
except Exception as err:
  print('Error - ',err) 

con.close()     
