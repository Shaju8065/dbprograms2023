import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')

curs=con.cursor()
cursor=con.cursor()

query="ALTER TABLE MOBILES ADD purpose VARCHAR(50)"
cursor.execute(query)
con.commit()
print("NEW COLUMN ADDED..")

con.close()