import pymysql

con=pymysql.connect(host='bfnxwec2m8abhwazdfb8-mysql.services.clever-cloud.com',user='ugaak4dhnkm4bgbj',password='TXOmMfbZNDpbewj1zL0e',database='bfnxwec2m8abhwazdfb8')
curs=con.cursor()

try:
    prodid=int(input('Enter Product ID to delete : '))
    curs.execute("select * from MOBILES where prodid=%d" %prodid)
    data=curs.fetchone()

    if data:
        print(data)
        cho=input('Do you really want to delete? (yes/no) : ')
        if cho.lower()=='yes':
            curs.execute("delete from MOBILES where prodid=%d" %prodid)
            con.commit()
            print('account closed successfully')
        else:
            print('delete cancelled by the user')
    else:
        print('account does not exist')
except:
    print('error in code')

con.close()